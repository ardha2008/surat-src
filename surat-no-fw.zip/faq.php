<?php require_once 'header.php'; ?>

<div class="row">
    <div class="col-md-12 column">
    <br /><br />
    <p><strong>FAQ</strong> atau <strong>Frequently asked questions</strong> adalah pertanyaan yang sering diajukan dalam daftar pertanyaan dan jawaban,sering ditanyakan dalam beberapa konteks, dan berkaitan dengan topik tertentu</p>
    
			<div class="panel-group" id="panel-703749">
				<div class="panel panel-default">
					<div class="panel-heading">
						 <a class="panel-title" data-toggle="collapse" data-parent="#panel-703749" href="#panel-element-458795">Collapsible Group Item #1</a>
					</div>
					<div id="panel-element-458795" class="panel-collapse in">
						<div class="panel-body">
							Anim pariatur cliche...
						</div>
					</div>
				</div>
				<div class="panel panel-default">
					<div class="panel-heading">
						 <a class="panel-title collapsed" data-toggle="collapse" data-parent="#panel-703749" href="#panel-element-592990">Collapsible Group Item #2</a>
					</div>
					<div id="panel-element-592990" class="panel-collapse collapse">
						<div class="panel-body">
							Anim pariatur cliche...
						</div>
					</div>
				</div>
			</div>
		</div>

</div>