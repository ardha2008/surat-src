<div class="col-md-4">
		<div class="panel panel-default">
			<div class="panel-heading"><i class="fa fa-th"></i> Manage</div>

			<div class="panel-body">
				<ul class="list-unstyled">
					<li><a href="./?page=pegawai/tambah"><i class="fa fa-plus"></i> Tambah Baru</a></li>
				</ul>
			</div>
		</div>
	</div>