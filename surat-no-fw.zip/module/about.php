<div class="col-lg-12">

	<p>Aplikasi ini dibuat untuk kepentingan tugas akhir</p>
</div>