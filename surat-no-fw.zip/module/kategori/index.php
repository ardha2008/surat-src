<div class="row">
    <div class="col-md-12">
        <div class="panel panel-primary">
            <div class="panel-heading"><i class="fa fa-th"></i> Kategori</div>
            
            <div class="panel-body">
                
            </div>
        
        </div>
    
    </div>
</div>