<div class="row">
    
    <div class="col-md-6">
        <div class="panel panel-default">
            <div class="panel-heading"><i class="glyphicon glyphicon-import"></i> Import .csv</div>
            
            <div class="panel-body">
                Import sql berfungsi sebagai memasukkan data yang bersumber dari file tipe .csv dari komputer menuju database aplikasi
            </div>
            
            <div class="panel-footer">
                <a href="./?page=import/excel"><button class="btn btn-block btn-primary">Selengkapnya</button></a>
            </div>
        </div>
    </div>
    
</div>