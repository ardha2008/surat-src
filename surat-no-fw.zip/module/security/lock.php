<div class="row">
    <div class="col-md-6 col-xs-8">
        <img src="./img/lock.jpg" />
    </div>
</div>