<div class="row">

    <div class="col-lg-12">
        <div class="alert alert-danger">
        <i class="fa fa-info"></i> Segala macam aktifitas akan masuk kedalam log, akan diperbarui per <?php echo date('d M Y') ?>
        </div>
    </div>
    
    <div class="clearfix"></div>
    
    <div class="col-lg-9">
        <div class="list-group">
        
        </div>
    
    </div>
</div>