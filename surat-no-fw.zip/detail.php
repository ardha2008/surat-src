<?php if(!isset($_GET['detail']) || $_GET['detail']!='surat') die('404'); ?>

<?php require_once 'header.php'; ?>
<?php require_once 'footer.php'; ?>