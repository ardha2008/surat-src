<hr />
	<div class="row clearfix">
		<div class="col-md-12 column">
			 &COPY;2014 Biro Kerjasama Dan Kemahasiswaan UPN Jatim
		</div>
	</div>
</div>
</body>
</html>
